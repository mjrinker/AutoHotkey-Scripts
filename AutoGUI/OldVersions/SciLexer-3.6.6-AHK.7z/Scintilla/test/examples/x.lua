--[[ coding:UTF-8
comment ]]
function first()
::開::
   -- Comment
   func(SCI_ANNOTATIONSETTEXT, 'a', 0, "LINE1")
end
