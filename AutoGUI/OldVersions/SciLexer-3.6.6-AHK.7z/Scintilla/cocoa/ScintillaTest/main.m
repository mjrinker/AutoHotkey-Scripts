/**
 * main.m
 * ScintillaTest
 *
 * Created by Mike Lischke on 02.04.09.
 * Copyright Sun Microsystems, Inc 2009. All rights reserved.
 * This file is dual licensed under LGPL v2.1 and the Scintilla license (http://www.scintilla.org/License.txt).
 */

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
